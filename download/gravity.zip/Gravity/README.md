# Gravity

Implementation of the Gravity Gun from Half Life 2, with the posibility of extending with different types of weapons.

The project was developed in 48 hours. Outside of the 48 hours, no functionality has been changed, the only changes done was to clean up and organize the existing code.