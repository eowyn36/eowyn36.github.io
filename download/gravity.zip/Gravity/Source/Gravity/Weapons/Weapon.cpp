#include "Weapon.h"
#include "Camera/CameraComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/RotatingMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
#include "../Characters/MainCharacter.h"

AWeapon::AWeapon() {
    // Set size for collision sphere
	CollisionSphere = CreateDefaultSubobject<USphereComponent>(FName("CollisionSphere"));
	CollisionSphere->InitSphereRadius(80);
	SetRootComponent(CollisionSphere);

    // Set up the mesh for the weapon
	SkeletalMesh = CreateDefaultSubobject<USkeletalMeshComponent>(FName("MeshComponent"));
	SkeletalMesh->bCastDynamicShadow = false;
	SkeletalMesh->CastShadow = false;
	SkeletalMesh->SetupAttachment(CollisionSphere);

    // Set up the rotating movement for the weapon
	RotatingMovement = CreateDefaultSubobject<URotatingMovementComponent>(FName("RotatingMovement"));
	RotatingMovement->RotationRate = FRotator(0, 180, 0);
	RotatingMovement->SetUpdatedComponent(GetRootComponent());
}

void AWeapon::OnPickUpWeapon(){
    // Stop the rotation when the weapon is picked up by the player
	RotatingMovement->RotationRate = FRotator(0, 0, 0);
}

void AWeapon::OnDropWeapon(){
    // Start the rotation when the weapon is dropped up by the player
	RotatingMovement->RotationRate = FRotator(0, 180, 0);

	// Set the location of the weapon so it is dropped in front of the player
	FVector forwardVector = UGameplayStatics::GetPlayerCameraManager(this, 0)->GetCameraRotation().Vector();
	forwardVector.Z = 0;
	FVector location = UGameplayStatics::GetPlayerCameraManager(this, 0)->GetCameraLocation() + (forwardVector * 200.f);
	location.Z -= 100;

	SetActorLocationAndRotation(location, FVector::ZeroVector.Rotation());
}

bool AWeapon::GetHitLocation(FHitResult& outHit, FVector& end) {
    UCameraComponent* FirstPersonCamera = Cast<AMainCharacter>(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0))->GetFirstPersonCameraComponent();
    FVector forwardVector = FirstPersonCamera->GetForwardVector();
    FVector start = FirstPersonCamera->GetComponentLocation();
    end = start + (forwardVector * Range);

    FCollisionQueryParams collisionParams;

    bool isHit = GetWorld()->LineTraceSingleByChannel(outHit, start, end, ECC_Visibility, collisionParams);

    if (isHit && outHit.bBlockingHit)
        end = outHit.ImpactPoint;

    return isHit;
}