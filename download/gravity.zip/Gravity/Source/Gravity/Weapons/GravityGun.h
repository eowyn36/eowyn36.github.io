#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PhysicsEngine/PhysicsHandleComponent.h"
#include "Particles/ParticleSystemComponent.h"
#include "Weapons/Weapon.h"
#include "GravityGun.generated.h"

UCLASS()
class GRAVITY_API AGravityGun : public AWeapon {
	GENERATED_BODY()

	bool isLevitating;

    /** Spawns Beam when the gun is fired */
	void SpawnBeam(FVector, FVector);

public:
	AGravityGun();

	void Tick(float DeltaTime) override;

	void Fire() override;

	void SecondaryFire() override;

	void StopLevitating();

	void OnDropWeapon();

    /** The strengt of the impulse created on items by firing */
	UPROPERTY(EditAnywhere, Category = Weapon)
	float impulseStrength;

    /** Particle system and its component to show the beam effect when fires */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapon)
 	UParticleSystem* BeamParticleSystem;

    /** Reference to the latest spawned beam */
	UParticleSystemComponent* Beam;

    /** Reference to Secondary fire/levitation sound component */
	class UAudioComponent* SecondaryFireAudioComponent;

protected:

    /** Physics component to handle carrying/levitating objects */
    UPhysicsHandleComponent* physicsHandle;

};
