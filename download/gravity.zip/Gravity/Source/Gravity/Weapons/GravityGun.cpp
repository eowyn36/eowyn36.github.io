#include "GravityGun.h"
#include "Camera/CameraComponent.h"
#include "Components/AudioComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"

AGravityGun::AGravityGun() {
 	// Set this actor to call Tick() every frame.
	PrimaryActorTick.bCanEverTick = true;

	physicsHandle = CreateDefaultSubobject<UPhysicsHandleComponent>("PhysicsHandleComponent");

	// Set the default values for this gun, which can be edited in the editor
	isLevitating = false;
	impulseStrength = 800000.0f;
	Range = 2000.f;
}

void AGravityGun::Tick(float DeltaTime) {
	Super::Tick(DeltaTime);
/*
	if (Beam != NULL && !Beam->HasCompleted())
 		Beam->SetBeamSourcePoint(0, SkeletalMesh->GetSocketLocation("Muzzle"), 0); */

    // As long as the gun is levitating an item, set the location and rotation of the item
	if (isLevitating) {
		physicsHandle->SetTargetLocationAndRotation(SkeletalMesh->GetSocketLocation("GravitationPoint"), SkeletalMesh->GetSocketRotation("GravitationPoint"));
	}
}

void AGravityGun::Fire() {
    // Figure out what are we hitting
	UPrimitiveComponent* compToHit = nullptr;
	FVector impactPoint = FVector::ZeroVector;
	FHitResult hitResult;
	FVector end;
	bool isHit = Super::GetHitLocation(hitResult, end);

	// If the gun is currently levitating an item, stop levitating
	if (isLevitating) {
		compToHit = physicsHandle->GetGrabbedComponent();
		impactPoint = SkeletalMesh->GetSocketLocation("GravitationPoint");
		StopLevitating();
	} else if (isHit && hitResult.bBlockingHit && hitResult.GetActor()->IsRootComponentMovable()) {
		compToHit = hitResult.GetComponent();
		impactPoint = hitResult.ImpactPoint;	
	}

	// Only add impulse if the the gun actually hit something
	if (compToHit != nullptr && !impactPoint.IsZero()) {
		compToHit->AddImpulseAtLocation(hitResult.Normal * -1 * impulseStrength, impactPoint);
	}

	// Always fire the beam
	SpawnBeam(SkeletalMesh->GetSocketLocation("Muzzle"), end);
}

void AGravityGun::SecondaryFire() {
	// If the gun is currently levitating an item, set it to false and release the levitated item
	if (isLevitating) {
		StopLevitating();
		return;
	}

	// Find the object to levitate
	FHitResult outHit;
	FVector end;
	bool isHit = Super::GetHitLocation(outHit, end);

	if (isHit && outHit.bBlockingHit && outHit.GetActor()->IsRootComponentMovable()) {
	    // Grab the hit item
		physicsHandle->GrabComponentAtLocationWithRotation(outHit.GetComponent(), "", outHit.GetComponent()->GetComponentLocation(), FRotator::ZeroRotator);
		isLevitating = true;
		// If an secondary fire sound is defined, spawn the audio at the muzzle location
		if (SecondaryFireSound != NULL) { 
			SecondaryFireAudioComponent = UGameplayStatics::SpawnSoundAttached(SecondaryFireSound, GetRootComponent(), FName("Muzzle"), SkeletalMesh->GetSocketLocation("Muzzle"), EAttachLocation::KeepRelativeOffset);
		}
	}
}

void AGravityGun::SpawnBeam(FVector start, FVector end) {
	Beam = UGameplayStatics::SpawnEmitterAtLocation(this, BeamParticleSystem, SkeletalMesh->GetSocketLocation("Muzzle"));
	Beam->SetBeamSourcePoint(0, start, 0);
	Beam->SetBeamTargetPoint(0, end, 0);

	// try and play the sound if specified
	if (FireSound != NULL) { 
		UGameplayStatics::PlaySoundAtLocation(this, FireSound, GetActorLocation());
	}
}

void AGravityGun::StopLevitating() {
    // Release the levitated item and stop the secondary fire sound
	isLevitating = false;
	physicsHandle->ReleaseComponent();
	
	if (SecondaryFireAudioComponent != nullptr) {
		SecondaryFireAudioComponent->FadeOut(1.f, 0);
	}
}

void AGravityGun::OnDropWeapon(){
	Super::OnDropWeapon();

	StopLevitating();
}

