#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Weapon.generated.h"

UCLASS()
class GRAVITY_API AWeapon : public AActor {
	
	GENERATED_BODY()
	
	UPROPERTY(VisibleAnywhere, Category = Mesh)
	class USphereComponent* CollisionSphere;

public:
	AWeapon();

    /** Fire action to be implemented for each weapon */
 	virtual void Fire() PURE_VIRTUAL(AWeapon::Fire,);

    /** Secondary fire action to be implemented for each weapon */
 	virtual void SecondaryFire() PURE_VIRTUAL(AWeapon::SecondaryFire,);

 	virtual void OnPickUpWeapon();

 	virtual void OnDropWeapon();

    /** Gets the hit location if the weapon hits something when fired, depending on the range */
 	bool GetHitLocation(FHitResult&, FVector&);

    /** Range of the weapon */
	UPROPERTY(EditAnywhere, Category = Weapon)
	float Range;

    /** Audio for fire */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapon)
	class USoundBase* FireSound;

    /** Audio for secondary fire */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapon)
	class USoundBase* SecondaryFireSound;

    /** Skelatal Mesh of the weapon */
	UPROPERTY(EditAnywhere, Category = Components)
	USkeletalMeshComponent* SkeletalMesh;

    /** Rotation movement for the weapon while it is on the ground */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Components)
	class URotatingMovementComponent* RotatingMovement;

};
