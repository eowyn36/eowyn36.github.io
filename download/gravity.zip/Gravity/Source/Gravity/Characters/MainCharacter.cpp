#include "MainCharacter.h"
#include "../Weapons/Weapon.h"
#include "Animation/AnimInstance.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "GameFramework/InputSettings.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"

DEFINE_LOG_CATEGORY_STATIC(LogFPChar, Warning, All);

AMainCharacter::AMainCharacter() {
    // Set size for collision capsule
    GetCapsuleComponent()->InitCapsuleSize(55.f, 96.0f);

    // Create a CameraComponent for the First Person view
    FirstPersonCameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
    FirstPersonCameraComponent->SetupAttachment(GetCapsuleComponent());
    FirstPersonCameraComponent->RelativeLocation = FVector(-39.56f, 1.75f, 64.f);  // Position the camera
    FirstPersonCameraComponent->bUsePawnControlRotation = true;

    // Create a mesh component that will be used when being viewed from a '1st person' view (when controlling this pawn)
    // This mesh will only have arms
    Mesh1P = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("CharacterMesh1P"));
    Mesh1P->SetOnlyOwnerSee(true);
    Mesh1P->SetupAttachment(FirstPersonCameraComponent);
    Mesh1P->bCastDynamicShadow = false;
    Mesh1P->CastShadow = false;
    Mesh1P->RelativeRotation = FRotator(1.9f, -19.19f, 5.2f);
    Mesh1P->RelativeLocation = FVector(-0.5f, -4.4f, -155.7f);
}

void AMainCharacter::BeginPlay() {
    Super::BeginPlay();

    // Hide the arms at start as the character is not holding a weapon at spawn
    Mesh1P->SetHiddenInGame(true, false);
}

// ----- Input Setup ----- //

void AMainCharacter::SetupPlayerInputComponent(class UInputComponent *PlayerInputComponent) {
    // set up gameplay key bindings
    check(PlayerInputComponent);

    // Bind jump events
    PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &ACharacter::Jump);
    PlayerInputComponent->BindAction("Jump", IE_Released, this, &ACharacter::StopJumping);

    // Bind fire and secondary fire events
    PlayerInputComponent->BindAction("Fire", IE_Pressed, this, &AMainCharacter::OnFire);
    PlayerInputComponent->BindAction("SecondaryFire", IE_Pressed, this, &AMainCharacter::OnSecondaryFire);

    // Bind item pick up and drop events
    PlayerInputComponent->BindAction("PickUp", IE_Pressed, this, &AMainCharacter::PickUpWeapon);
    PlayerInputComponent->BindAction("Drop", IE_Pressed, this, &AMainCharacter::DropWeapon);

    // Bind movement and rotation events
    PlayerInputComponent->BindAxis("MoveForward", this, &AMainCharacter::MoveForward);
    PlayerInputComponent->BindAxis("MoveRight", this, &AMainCharacter::MoveRight);
    PlayerInputComponent->BindAxis("Turn", this, &APawn::AddControllerYawInput);
    PlayerInputComponent->BindAxis("LookUp", this, &APawn::AddControllerPitchInput);
}

// ----- Primary and Secondary Actions ----- //

void AMainCharacter::OnFire() {
    // If the character is holding a weapon trigger the weapons fire
    if (currentWeapon == nullptr)
        return;

    currentWeapon->Fire();

    // If there is a defined fire animation for the character (ie. arms moving), trigger the animation
    if (FireAnimation != NULL) {
        // Get the animation object for the arms mesh
        UAnimInstance *AnimInstance = Mesh1P->GetAnimInstance();
        if (AnimInstance != NULL) {
            AnimInstance->Montage_Play(FireAnimation, 1.f);
        }
    }
}

void AMainCharacter::OnSecondaryFire() {
    // If the character is holding a weapon trigger the weapons secondary fire
    if (currentWeapon == nullptr)
        return;

    currentWeapon->SecondaryFire();
}

// ----- PickUp/Drop ----- //

void AMainCharacter::PickUpWeapon() {
    //Find if there are any weapons in range to be picked up
    TArray<AActor*> ItemsInRange;
    GetOverlappingActors(ItemsInRange, TSubclassOf<AWeapon>());

    if (ItemsInRange.Num() > 0) {
        currentWeapon = Cast<AWeapon>(ItemsInRange[0]); // This needs better logic, for example pick the weapon the actor is looking at
        currentWeapon->AttachToComponent(Mesh1P, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true), TEXT("GripPoint"));
        currentWeapon->OnPickUpWeapon();

        // Show the hands holding the weapon
        Mesh1P->SetHiddenInGame(false, false);
    }
}

void AMainCharacter::DropWeapon() {
    if (currentWeapon != nullptr) {
        currentWeapon->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
        currentWeapon->OnDropWeapon();

        // Hide the hands as there is no weapon
        Mesh1P->SetHiddenInGame(true, false);
        currentWeapon = nullptr;
    }
}

// ----- Movement ----- //

void AMainCharacter::MoveForward(float Value) {
    if (Value != 0.0f) {
        AddMovementInput(GetActorForwardVector(), Value);
    }
}

void AMainCharacter::MoveRight(float Value) {
    if (Value != 0.0f) {
        AddMovementInput(GetActorRightVector(), Value);
    }
}
