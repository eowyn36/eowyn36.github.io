#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "MainCharacter.generated.h"

class UInputComponent;

UCLASS(config = Game)
class AMainCharacter : public ACharacter {

    GENERATED_BODY()

    /** Skeletal mesh of 1st person view, just arms */
    UPROPERTY(VisibleDefaultsOnly, Category = Mesh)
    class USkeletalMeshComponent *Mesh1P;

    /** First person camera */
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
    class UCameraComponent *FirstPersonCameraComponent;

public:
    AMainCharacter();

    /** Animation to play each time character fires */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Gameplay)
    class UAnimMontage *FireAnimation;

    /** Current weapon character is holding, if any. */
    UPROPERTY(EditAnywhere, Category = Gameplay)
    class AWeapon *currentWeapon;

    /** Returns Mesh1P component **/
    FORCEINLINE class USkeletalMeshComponent *GetMesh1P() const { return Mesh1P; }

    /** Returns FirstPersonCameraComponent subobject **/
    FORCEINLINE class UCameraComponent *GetFirstPersonCameraComponent() const { return FirstPersonCameraComponent; }

protected:
    virtual void BeginPlay();

    virtual void SetupPlayerInputComponent(UInputComponent *InputComponent) override;

    /** Fires the current weapon */
    void OnFire();

    /** Secondary fire for the current weapon */
    void OnSecondaryFire();

    void PickUpWeapon();

    void DropWeapon();

    /** Handles moving forward/backward */
    void MoveForward(float Val);

    /** Handles stafing movement, left and right */
    void MoveRight(float Val);

};

