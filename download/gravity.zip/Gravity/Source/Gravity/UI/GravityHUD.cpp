#include "GravityHUD.h"
#include "CanvasItem.h"
#include "Engine/Canvas.h"
#include "Engine/Texture2D.h"
#include "TextureResource.h"
#include "UObject/ConstructorHelpers.h"

AGravityHUD::AGravityHUD() {

    // Sets the crosshair texture
	static ConstructorHelpers::FObjectFinder<UTexture2D> CrosshairTexObj(TEXT("/Game/UI/Textures/Crosshair"));
	CrosshairTex = CrosshairTexObj.Object;
}

void AGravityHUD::DrawHUD(){

	Super::DrawHUD();

	// Offset by half the texture's dimensions so that the center of the texture aligns with the center of the Canvas
	const FVector2D CrosshairDrawPosition( (Canvas->ClipX - CrosshairTex->GetSizeX()) * 0.5f, (Canvas->ClipY - CrosshairTex->GetSizeY()) * 0.5f);

	// Draw the crosshair
	FCanvasTileItem TileItem( CrosshairDrawPosition, CrosshairTex->Resource, FLinearColor::White);
	TileItem.BlendMode = SE_BLEND_Translucent;
	Canvas->DrawItem(TileItem);
}
