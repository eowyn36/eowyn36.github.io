#include "GravityGameMode.h"
#include "Characters/MainCharacter.h"
#include "UI/GravityHUD.h"
#include "UObject/ConstructorHelpers.h"

AGravityGameMode::AGravityGameMode(): Super() {

	// Set default pawn class to an blueprint that extends the the MainCharacter
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnClassFinder(TEXT("/Game/Characters/Blueprints/BP_FirstPersonCharacter"));
	DefaultPawnClass = PlayerPawnClassFinder.Class;

	// Set the HUD class
	HUDClass = AGravityHUD::StaticClass();
}
