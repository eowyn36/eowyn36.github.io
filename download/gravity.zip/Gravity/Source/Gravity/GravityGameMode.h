#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GravityGameMode.generated.h"

UCLASS(minimalapi)
class AGravityGameMode : public AGameModeBase {
	GENERATED_BODY()

public:

	AGravityGameMode();

};



